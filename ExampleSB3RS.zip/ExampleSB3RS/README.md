# rlgym_quickstart_tutorial_bot
 A rocket league reinforcement learning bot made to get you up and running as fast as possible. Video guide available here: https://youtu.be/C92_UFZ1W-U
